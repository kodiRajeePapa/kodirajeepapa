#   Copyright (C) 2017 Lunatixz
#
#
# This file is part of filmriseTV.
#
# filmriseTV is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# filmriseTV is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with filmriseTV.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

import os, sys
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID = 'plugin.video.filmrisetv'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = REAL_SETTINGS.getAddonInfo('name')
ADDON_PATH = (REAL_SETTINGS.getAddonInfo('path').decode('utf-8'))
ADDON_VERSION = REAL_SETTINGS.getAddonInfo('version')
SETTINGS_LOC = REAL_SETTINGS.getAddonInfo('profile')
ICON = REAL_SETTINGS.getAddonInfo('icon')
FANART = REAL_SETTINGS.getAddonInfo('fanart')

def start():
    addDir(
        title="GoldMines-Hindi",
        url="plugin://plugin.video.youtube/channel/UCOF23vGxkbhN4wl7ROrgXsA/")
    addDir(
        title="Gold Cinema",
        url="plugin://plugin.video.youtube//channel/UCpPhccdseiSKsCtgibWnzaA/")  
    addDir(
        title="B4U Classics",
        url="plugin://plugin.video.youtube/channel/UCLssvYr2S_C_q26RnSYLWmQ/")
    addDir(
        title="Music-Bollywood Classics",
        url="plugin://plugin.video.youtube/user/BollywoodClassics/") 
    addDir(
        title="Hindusthan Record VintageGlory",
        url="plugin://plugin.video.youtube/channel/UCIaYW3LyBG6LCpo-Q_36fIw/")
    addDir(
        title="Hindustani Classical",
        url="plugin://plugin.video.youtube/channel/UCjm_2mMYXUEjWzSVsA6Wshg/")  
    addDir(
        title="DarbarFestival",
        url="plugin://plugin.video.youtube/channel/UCWEJt0-LJuRE0seaIMIm2jA/")
    addDir(
        title="Bollywood Paradise",
        url="plugin://plugin.video.youtube/channel/UCRfyI8fUuai-VuDT7gsF04A/")
    addDir(
        title="4K Music",
        url="plugin://plugin.video.youtube/channel/UCfAMn-h-Xo9bZoeYriLwuCg/")
    addDir(
        title="Cinecurry Marathi",
        url="plugin://plugin.video.youtube/channel/UCg20Am9GzsC7D0R4n9LnjLw/")  
    addDir(
        title="Marathi Natak By PRISM VIDEO",
        url="plugin://plugin.video.youtube/channel/UCGE25HmZDnnHNVaZEyU8TrQ/")
    addDir(
        title="Marathi Natak By EVEREST MARATHI",
        url="plugin://plugin.video.youtube/user/EverestTalkies/") 
    addDir( 
     	title="Marathi Natak By EVEREST MARATHI",
        url="plugin://plugin.video.youtube/user/EverestTalkies/")
    addDir(
        title="Rajee-Playlists",
        url="plugin://plugin.video.youtube/channel/UCXAZucV_pLeUeAYnFu7s0MA/") 
    addDir(
        title="BBC Documentries",
        url="plugin://plugin.video.youtube/channel/UCZEPItn2Nb62Zso5eohHAAA/")
    addDir(
        title="Documentries",
        url="plugin://plugin.video.youtube/results?search_query=national+geographic+documentary/")		
		

    
  
def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
start()
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)